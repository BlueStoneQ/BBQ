# 待分类
1. 一个js应用可以使用另一个js应用的模块
2. APP1 引用 APP2的模块：
```js
// App1:
plugins: {
  remotes: {}
}

// app2 webpack-config:
new ModuleFederationPlugin({

})
``` 
3. 构建阶段