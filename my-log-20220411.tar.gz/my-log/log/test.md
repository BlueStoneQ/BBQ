1. 深入理解TypeScript
1. css重构 样式表性能调优
1. 微信小程序项目开发实战
1. react native开发指南
2. react native实战：javascript开发IOS和Android应用
3. React Native移动开发指南
4. React Native跨平台应用开发
1. Flutter:从0到1构建大前端应用
2. flutter技术入门与实战
2. Dart编程语言
1. Electron跨平台开发实战
2. 跨平台桌面应用开发：基于Electron与NW.js
1. 狼书（共3卷）
1. 精通Nginx
2. linux 命令行与shell编程大全
3. Nodejs调试指南
2. 深入浅出Mysql 数据库开发 优化与管理维护
4. redis入门指南
5. MongoDB应用设计模式
1. git团队协作
1. GitHub实战
2. Git版本控制管理
4. 完全学会Git GitHUb Git server的24堂课
5. 软件工程
1. Adroid高级编程
1. 20天App开发从0到1 APIcloud移动开发实践
3. Adroid App开发实战：从零基础到App上线
4. 一个App的诞--从零开始设计你的手机应用
5. App后台开发运维和架构实践
1. web安全开发指南
1. 推荐系统实践
2. 推荐系统算法实践
3. 算法
1. 高性能网站建设指南
1. 微服务设计
1. 微服务架构设计模式
2. 微服务架构与实践
3. Docker微服务架构实战
1. RestFul webApis
1. web Api的设计与开发
1. 微服务设计
2. 前端架构设计
3. 架构之美
1. 从零开始学架构
1. App交互设计全流程图解
2. 产品逻辑之美：打造复杂的产品系统
1. 代码整洁之道
2. 重构 改善既有代码设计
1. 程序员的英语
2. 程序员修炼之道:从小工到专家
3. 程序员思维修炼
6. 代码之外的功夫 程序员精进之路
7. 程序员的数学
8. 深入浅出https
3. 幕后产品 打造突破式产品思维