const json = {
  "startEndInfo": {
    "regular": {
      "title": "活动规则",
      "regularList": [
        "1. 规则一...",
        "2. 规则二..."
      ]
    },
    "cityId1": {
      "advertise": "最高立减15元",
      "startTime": "2020-2-20",
      "endTime": "2020-3-4",
      "discount": "活动期间...9折优惠"
    },
    "cityId2": {
      "advertise": "最高立减10元",
      "startTime": "2020-2-19",
      "endTime": "2020-3-5",
      "discount": "活动期间...8折优惠"
    }
  }
}

console.log(JSON.stringify(json));