## 4-8 二期简历todo


## 4-1 todo
```
TODO的设计考虑：
是否必须保留
学习成本的高低
优先级
```
### 基础
- 正则：单项训练：边界 小组 js相关的api使用
- 动画
- nodejs执行命令行
  - process child_process相关
- http缓存
### 专项
- webpack 应用
  - ark cli中用到了 一定要能理解 和 说上
- koa的中间件原理
- node
  - 执行命令行的方案
- 鉴权：SSO
- git的常见场景 和 原理
