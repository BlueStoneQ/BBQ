## 课程
- [算法就像搭乐高：LRU](https://mp.weixin.qq.com/s?__biz=MzAxODQxMDM0Mw==&mid=2247486428&idx=1&sn=3611a14535669ba3372c73e24121247c&scene=21#wechat_redirect)
  - 这个题：难点倒不是算法，而是数据结构的设计 + 写出不出bug的完备的算法 是比较考验编程能力和算法水平的
  - me： 好的数据结构的设计是解决算法问题的一半

### LRU缓存机制 146
- 核心数据结构：哈希链表 LinkedHashMap （双向链表和哈希表的结合体）
  - 分析：
    - 哈希表查找快，但是数据无固定顺序；
    - 链表有顺序之分，插入删除快，但是查找慢

- 实现linkedHashMap
  - 注意我们实现的双链表 API 只能从尾部插入，也就是说靠尾部的数据是最近使用的，靠头部的数据是最久为使用的。
- 在一个算法中同时使用联动的2种数据结构：由于我们要同时维护一个双链表 cache 和一个哈希表 map，很容易漏掉一些操作，比如说删除某个 key 时，在 cache 中删除了对应的 Node，但是却忘记在 map 中删除 key。

    解决这种问题的有效方法是：在这两种数据结构之上提供一层抽象 API。

    说的有点玄幻，实际上很简单，就是尽量让 LRU 的主方法 get 和 put 避免直接操作 map 和 cache 的细节。我们可以先实现下面几个函数
    - me: 我会直接二次封装为一种
  - 底层方法(将map和linked的同步问题封装起来了)：
    - 提升为最新：将某个 key 提升为最近使用的
      - 从map中根据key拿到node（引用）
      - 将linked中的该node删除
      - 该node插入到linked的队尾
    - 添加最近使用的元素（k, v）
      - new 新的node
      - 添加到列表队尾（node）
      - 添加到map（k，node）
    - 删除某一个 key
      - 通过key拿到node引用
      - 删除hashMap中的node
      - 删除linked中的key：node
    - 删除最久未使用的元素
      - 删除链表头部，拿到del-node
      - 删除map中的对应的key
  - 基于以上底层 linkedHashMap再提供：（通过层层封装 - 分散复杂度）：
    - get
      - 防御：key不存在
      - 提升该key
      - 返回给key映射的node.key
    - put
      - key已存在
        - 删除旧的key：node
        - new新的key:node
        - 将新key:node添加到最新
      - key不存在
        - 生成新的key:node
        - 容量已满
          - 淘汰最久未使用的key：node
          - 插入key：node为最近使用的数据
        - 容量未满
          - 插入key：node为最近使用的数据
    - remove
      - 删除最久未使用的元素


### me: 
  - 其实在js中 估计这样一个基础数据结构就能满足：[ { key:  }, {} ]
  - 要考虑复杂度
  - 在js中没有这些现成的数据结构 - 需要自己能够从底层封装