# 教材
- [回溯算法NB](https://mp.weixin.qq.com/s?__biz=MzAxODQxMDM0Mw==&mid=2247490981&idx=1&sn=db17864d2f6f189d63e051e434c05460&scene=21#wechat_redirect)
  - 之前说过回溯算法是笔试中最好用的算法，只要你没什么思路，就用回溯算法暴力求解，即便不能通过所有测试用例，多少能过一点
  - 好比说列举所有可能性的 或者 求所有可能性中的最值的
    - 有重复子问题的 可以用动态规划去优化
    - 动规 = 优化了子问题的回溯
  - 通俗来说，我们应该尽量「少量多次」，就是说宁可多做几次选择，也不要给太大的选择空间；宁可「二选一」选k次，也不要 「k选一」选一次。
  - 撤销选择：更应该被描述成为 恢复当前节点状态

### 698 划分为k个相等子集
- 理解题目：你可以想象将n个数字分配到k个「桶」里，最后这k个「桶」里的数字之和要相同。你可以想象将n个数字分配到k个「桶」里，最后这k个「桶」里的数字之和要相同。
- 递归遍历数组
```c++
void traverse(int[] nums, int index) {
    if (index == nums.length) {
        return;
    }
    System.out.println(nums[index]);
    traverse(nums, index + 1);
}
```
- 这题跟我之前根据文件行数给大家分配自动化测试的文件个数很像，都是往桶里放东西，让每个桶里的东西和一样
#### 方法1 以数字的视角 选择自己进入哪个桶
- 数据结构设计：
```c++
// 理论上每个桶（集合）中数字的和
    int target = sum / k;
// k 个桶（集合），记录每个桶装的数字之和
    int[] bucket = new int[k];
```
- base-case:
```c++
if (index == nums.length) {
        // 检查所有桶的数字之和是否都是 target
        for (int i = 0; i < bucket.length; i++) {
            if (bucket[i] != target) {
                return false;
            }
        }
        // nums 成功平分成 k 个子集
        return true;
    }
```
- backtrack设计
```c++
boolean backtrack(int[] nums, int index, int[] bucket, int target)
```
- 关于剪枝：
  - 优化思路，优化掉不必去遍历的部分
  - 例如判断bool的 这种 可以扩大优先碰到剪枝条件的可能性 减少无谓的判断
#### 方法1 以桶的视角 选择数字要不要进来
- backtrack函数
```
boolean backtrack(int k, int bucket, int[] nums, int start, boolean[] used, int target);
```




