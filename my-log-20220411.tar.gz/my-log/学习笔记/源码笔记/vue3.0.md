## 工程化解析
```
npm-cli的设计 我们也参考下vue-cli
直接找业界最top的老师学习
直奔最新 一步到位
不破不立

vue的战略意义：base型项目
一口气拉升我的水平到业界top
从编码到各个综合能力
然后基于这个能力
去查漏补缺
去体系化能力
去建设开源
去描述各个方面的事例

我有一个好心态
It's my life
放下那些 
只focus到有建设性的事情上
愈战愈勇
专业的姿态
睥睨挑战困难
```
### 学习目标
1. 提升前端软件的架构和编码能力
2. 学习行业顶尖的工程化方案
3. 了解vue源码
  - 架构设计
  - 功能设计和实现
4. 自己手写一个min-vue  
  - 核心功能完备，边界可以不完备
  - 工程化思路清晰，min但是完备
5. 有可能的话，提一个commit给vue全家桶
### package.json解读
```
技术选型 也往往透露着很多方案的业界最佳实践
```
- scripts设计
  - dev系列
  - build系列
  - test系列
    - unit
    - e2e
  - lint系列
  - release系列？
  - size？
  - 其他
    - changelog
- 技术选型-dev
  - babel
  - vite
  - rollip系列
  - typescript系列
  - vue系列
    - core
    - dom
    - reactivity
  - jest
    - ts-jest
    - puppeteer
  - eslint
    - prettier
  - 工具：
    - lodash
    - semver
    - fs-extra
    - execa： 代替2.0中的shelljs
    - serve：?
- 协议
  - MIT

### 构建
#### 构建入口
1. "build": "node scripts/build.js"
2. 构建是基于（读取）特定目录package/ + 配置，一次性进行多个面向各种平台环境的打包（例如 web weex），是一种批量化构建策略
3. 

## 源码解析
### 源码入口
1. 首先，在使用中我们的入口：
```js
Vue.createApp()
将与Dom联系起来
该api由@vue/runtime-dom提供：
文件位置：vue-next/packages/runtime-dom/src/index.ts
```
2. 如何与我们的真实dom-root节点挂钩的，观看一个min-example
```
<div id="counter">
  Counter: {{ counter }}
</div>
const Counter = {
  data() {
    return {
      counter: 0
    }
  }
}

Vue.createApp(Counter).mount('#counter')
```
createApp的入参，是我们的vue描述对象（配置文件），通过返回值的mount()挂钩到dom-root节点上

### 带着问题去学习实现
- 是通过什么方案 和 我们的代码 挂钩的？挂在#app上做了什么？
- 生命周期管理方案？
- 模块化/组件化方案？
  - 模板的实现？
  - 模板中指令的实现？
  - 事件系统？
- virturalDom的设计和实现？
- 双向绑定实现方案？即响应式实现？
- diff的实现？
- 插件系统设计和实现方案？
- TS相关的工程化?

### 关于这些方案：一些自己的思考：如何设计会更好

### 编程技巧积累
1. 工程化中 利用node.os实现多核构建：
2. cpu核数：当任务数多于cup核数时，？? 在runParallel中cpu核数的真正作用是？
```js
async function buildAll(targets) {
  await runParallel(require('os').cpus().length, targets, build)
}
// build 使用execa分别开启一个线程（线程一般和cup数量对齐），启动的线程数，和targets的数量对齐，一个targets一般对应一个built
execa()
// 通过execa以命令行的方式调用rollup进行打包
```



### 衍生非主线问题

### 问题查询
1. 为什么vue需要nextTick？
  - 由于Vue DOM更新是异步执行的，即修改数据时，视图不会立即更新，而是会监听数据变化，并缓存在同一事件循环中，等同一数据循环中的所有数据变化完成之后，再统一进行视图更新。为了确保得到更新后的DOM，所以设置了 Vue.nextTick()方法。

  使用场景：
    - 在Vue生命周期的created()钩子函数进行的DOM操作一定要放在Vue.nextTick()的回调函数中。
    - 在数据变化后要执行的某个操作，而这个操作需要使用随数据改变而改变的DOM结构的时候，这个操作应该放在Vue.nextTick()的回调函数中。

### TODO
- 当发觉有写的不好的时候（或者有更好性能之类的写法的时候） 按照规范的流程提issue给Vue
- 源码阅读：vue全家桶-生态设计：？
  - vue-cli
  - vue-router
  - vuex

# 参考
- [聊聊源码学习](https://juejin.cn/post/6844903617762492423)
  - 全盘了解、问题驱动、主线优先、参与共建、阅读技巧、辅助资料
- [vue3.0源码](https://github.com/vuejs/vue-next.git)
- [vue源码文章大全](https://github.com/vue3/vue3-News/issues/16)
- [vue3.0源码解析-分目录](https://lq782655835.github.io/blogs/vue/vue3-code-3.api-analysis.html)
- [学习源码对工作的收益](https://ustbhuangyi.github.io/vue-analysis/v3/new/#%E5%AD%A6%E4%B9%A0%E6%BA%90%E7%A0%81%E5%9C%A8%E5%B7%A5%E4%BD%9C%E4%B8%AD%E7%9A%84%E6%94%B6%E7%9B%8A)
  - 虽然官方没有直接支持 CSP 兼容版本的 Vue.js，但对于我们来说，现阶段最小成本解决问题的方式就是使用一个 CSP 兼容版本的 Vue.js，所以只能魔改 Vue.js 了
  - 我们平时经常会强调技术选型的能力，其实技术选型的一个标准，就是你选择的第三方依赖，你能不能 hold 住。首先是你知道它的职责边界，知道它能做什么不能做什么，怎么利用它帮助你开发需求；其次是出了错你能不能快速定位到原因，知道是依赖的问题还是自身使用的问题；最后就是当它不能满足你的需求，并且官方不愿意解决或者不维护的情况下，你能不能去 fork 这个库，自己开发解决并实现。那么显然拥有这些能力就需要你对它的源码实现非常了解，所以这也是一些高阶岗位为什么会在面试中考察你对技术原理掌握的一方面原因
  - 很多人抱怨加班多，不妨问问自己，有多少时间是在写业务，多少时间是在写（找） bug。快速定位问题解决 bug，可以有效地提升你的工作效率，很可能就不用加班了，甚至会多出学习的时间，形成一个良性循环。
  - 我们在阅读的源码的时候，也可以把源码中的优秀的设计思想、代码实现吸纳到我们平时的开发工作中。
- [vue3.0发布-视频](https://juejin.cn/post/6874020661476458503)
  - 工程师气质：学会叙述技术和包装自己
- [vue3详细设计思路-尤雨溪](https://zhuanlan.zhihu.com/p/424940854)
  - Vue有一个相当独特的渲染策略：它提供一个接近HTML（HTML-like）的模板语法，并最终把它编译为一个可以返回虚拟DOM树的渲染函数。该框架通过递归遍历两个虚拟DOM树并比较每个节点上的每个属性来确定实际DOM的哪些部分需要更新。
  - 优化1：消除不必要的虚拟DOM树遍历和属性比较
  - 优化2：框架级的tree-shaking:
    - 框架的体积同样影响着它的性能,不是所有人都会用到框架的所有功能,理想情况下，用户应该能够在构建时删除那些未使用的框架特性相关的代码 – 也叫tree-shaking，只留下他们用到的东西
    - 框架中的一些部分永远不能被tree-shaking，因为它们对任何一个应用都是必要的。我们称这些不可缺少的部分的体积为基准体积。尽管增加了大量的新特性，但Vue 3的基准体积用gzip压缩后只有大约10KB - 比Vue 2的一半还小。
    - 挑战在于，class所依赖的许多语言特性，例如类字段和修饰器，仍处于建议阶段。而在成为正式的JavaScript标准之前，这些特性仍然可能变化.这些问题所涉及的复杂性和不确定性让我们怀疑添加类API是否真的合理
    - 渐进式框架”，含义就是封装由此过程产生的分层API设计
      - 在Vue的用户群中，有超过100万的开发人员是对HTML/CSS只有基本知识的初学者，或由jQuery转型而来的专业人士，或从其他框架迁移而来，或寻求前端解决方案的后端工程师，以及处理大规模软件的软件架构师。开发者的多样性造成了使用场景的多样性：一些开发人员可能希望在遗留应用程序上增加交互性；而另一些人则可能从事开发周期很短但维护时间有限的一次性项目；架构师可能必须处理大型、多年的项目，以及面对在项目生命周期中变化不定的开发团队。
  - [vue3.0目录分析](https://zhuanlan.zhihu.com/p/389511988)