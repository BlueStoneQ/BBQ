# [Babel插件手册](https://github.com/jamiebuilds/babel-handbook/blob/master/translations/zh-Hans/plugin-handbook.md#definitions%25E5%25AE%259A%25E4%25B9%258)

# 学习时间
```
预估3pd = 3 * 1.5 = 4.5h
```
 - 12-16
 - 12-17

# [书签12-17](https://github.com/jamiebuilds/babel-handbook/blob/master/translations/zh-Hans/plugin-handbook.md#%E6%9E%84%E5%BB%BA%E8%8A%82%E7%82%B9)

```
可以想象这些访问器一个一个在ast中遍历的情形
```

## 笔记

## 概念
- 标识符literal

- body
```
function f() {
  // {}中的函数体就是body
}
```

- binding 绑定
  - 所有引用属于特定的作用域，引用和作用域的这种关系（的描述，其实就是一个json节点）被称作：绑定（binding）
  - 典型用例：代码压缩时，可以查找一个绑定的所有引用信息
```yaml
Text for Translation
{
  identifier: node,
  scope: scope,
  path: path,
  kind: 'var',

  referenced: true, // 是否被引用
  references: 3, // 被引用的地方有几处
  referencePaths: [path, path, path], # 被引用的path list

  constant: false,
  constantViolations: [path]
}
```

## 访问
### 可以访问多种节点的访问器：
如有必要，你还可以把方法名用|分割成Idenfifier |MemberExpression形式的字符串，把同一个函数应用到多种访问节点。.

在flow-comments 插件中的例子如下：

```js
const MyVisitor = {
  "ExportNamedDeclaration|Flow"(path) {}
};
```
### 获取路径、节点
  - 获取当前节点
  - 获取父级
  - 获取兄弟
    - 判断是否有同级节点
    - 路径是在一个 Function／Program中的列表里面，它就有同级节点
  - 获取子孙

- path
  - 更像一个描述节点的schema

- 访问节点
  - 属性值
  - 节点path（get操作）


### 检查节点/路径
  - 类型
  - 属性值
  - 是否被引用

### 停止遍历
  - return 

## 处理
```
理解行为本身
而不是API
```
### 替换
  - 替换一个节点
  - 多节点替换单节点
  - 用字符串源码替换节点
  - 插入兄弟节点
    - before
    - after
  - 插入到容器中

### 删除一个节点
### 父节点操作
  - 替换变量是否被绑定
  - 删除

### scope 域/作用域
  - 检查本地
  - 创建一个UID
  - 重命名绑定及其引用

## 插件选项
- 在插件配置时开放一些配置给用户，插件中可以访问到配置信息
- 插件的准备/收尾工作
  - 例如：清理（cache）/ 分析
- 在插件中启用其他语法
- 抛出一个语法错误

## 构建节点


# me
## 原子操作
- parse阶段：
  - 正则

## 专业化描述&启发
- Babel 帮你管理这一切，从而使得节点操作简单，尽可能做到无状态。
  - 工程化也可以使用帮助管理这一思路

## 设计任务
```
贴近自己目前做的工程化，设计一个使用babel可以解决的问题, 和任务
目前来看，因为转换要求严格，可能写出安全的插件成本比较高，相比于收益，可能暂时不优先考虑使用
- 但是：对于一些硬编码之类的 可以处理
```
1. 