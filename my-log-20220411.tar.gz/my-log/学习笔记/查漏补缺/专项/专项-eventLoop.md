# 阅读
- [eventLoop](https://mp.weixin.qq.com/s/q_5c4wzsxOHiqHlPfqarzQ)

## js运行原理
- 执行栈
- 事件队列
- 堆(对象 数据)

### event-loop
- 为什么需要eventLoop：
  - 因为js的运行是单线程（只有一个主线程），要做到非阻塞 - 用的就是event-loop
- 

### 任务类型
- 同步任务
  - 主线程直接执行
- 异步任务
  - 