## 意义
1. 工程化水平 - 脚手架：集大成之作
## 工程结构设计
- monorepo
  - npm-cli 是一个总调度的职能，下面的都是一些monoRepo，都可以单独发版，可以扩展
    - npm包
    - cli工程
    - 组件库项目
    - m端项目
      - monorepo项目
      - 微前端架构
      - 微前端 + monoRepo混合
    - vue
    - react
    - ts