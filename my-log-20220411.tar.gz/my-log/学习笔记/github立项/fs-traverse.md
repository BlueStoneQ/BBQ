## 专业化 流程
0. 基础工程化：引入：TS lint jest
  - 引入ts
  - 配置好ts
1. 先实现核心遍历方法
2. 使用访问器模式：参考babel
  - 访问者模式学习：后面抽出来 作为设计模式中的补充：
3. 处理好边界：才是专业的体现 实现的方法是工业级的
4. 引入test（和边界互相成就）- 10个test左右
3. 引入lint
4. 更新readme: 描述要体现专业性 体现水平
4. npm包装 发布

## 功能设计
1. 增加bin - 可以提供cli操作？ - 不需要

## 工程化建设
1. ts是编译器，我们最终跑的是dist中的，发布的也是dist中的代码
2. threaft-hub就是用ts全程开发的 估计还能找到代码
3. 增加lint
### 在node中使用ts
- [参考fs-extra](https://github.com/jprichardson/node-fs-extra.git)
- (ts-node)[https://github.com/TypeStrong/ts-node]
- [范例：nestjs](https://github.com/nestjs/nest)
- [ts项目是如何工作的](https://segmentfault.com/a/1190000022497512)
- [ts是一种思维方式](https://zhuanlan.zhihu.com/p/63346965)
  - TS 做为 JS 的超集，其「超」其实主要在两方面
    - TS 为 JS 引入了一套类型系统；
    - TS 支持一些非 ECMAScript 正式标准的语法，比如装饰器；
  - 关于类型断言，我看文档时的疑惑点在于，我想不到什么情况下会使用它。后来发现，当你知道有这么一个功能，在实际使用过程中，就会发现能用得着，比如说迁移遗留项目时。
  - interface 和 type interface 和 type 都可以用来定义一些复杂的类型结构，最很多情况下是通用的，最初我一直没能理解它们二者之间区别在哪里，后来发现，二者的区别在于：
    interface创建了一种新的类型，而 type 仅仅是别名，是一种引用；
    如果 type 使用了 union operator （|） 操作符，则不能将 type implements 到 class 上；
    如果 type 使用了 union（|） 操作符 ，则不能被用以 extends interface
    type 不能像 interface 那样合并，其在作用域内唯一； [1]
  - 虽然站在作者的角度看，TS 弊大于利，主要原因是 TS 提供的功能大多都可以用其它工具配合在一定程度上代替，而且类型系统会需要写太多额外的代码，类型系统在一定程度上也破坏了动态语言的灵活性，让一些动态语言特有的模式很难在其中被应用。作者最终的结论带有很强的主观色彩，我并不是非常认可
- 学习新的东西最好还是从自己最熟悉的内容入手，所以不妨先看中文文档
  - [ts-hand-book](https://www.tslang.cn/docs/handbook/basic-types.html)
