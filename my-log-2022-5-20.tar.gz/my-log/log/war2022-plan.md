## 3-1~3-31 中期筑基：武器库建设 砺剑
```
进攻万花筒
解决方案提供商
```
1. 先能拿到offer
2. 拿到好的offer

## 2-17~2-28 抢滩登陆

## 2022过年上甘岭 1-29~2-7
```
吴军：30分的努力
```
1. 算法刷题
  - 标签：
    - 数组-> 字符串 -> 链表-> 栈与队列 -> 哈希表->树 ->  大小堆查找 -> DFS/BFS -> LRU/LFU -> 排序 -> 回溯 -> 动态规划 -> 贪心 -> 位运算 -> 数学算法
    - 东哥优先（武器库实战前强化-先把文中的例题找出来做 - 5min没思路 就看东哥的文章）：
      - https://mp.weixin.qq.com/s/ir1Hk06HcT8W_qz0MtyONA
      - 数据结构： 数组 - 链表 - 二叉树 - 设计数据结构（队列 栈 hash 前缀树 LRU LFU）
      - 必知必会算法技巧：暴力搜索：DFS BFS  数学运算技巧 其他算法技巧 经典面试题
      - 这里刷完：可以去刷一波code-Top 按照标签刷一下 动规留到最后
      - 动规：经典 子序列 背包 玩游戏 贪心
  - 题集：
    - 刷完题codeTop: MS-BT-SHOP-ALI （FE部分，同一标签-按照频度）
      - easy:
        - MS-FE
        - BT-FE
        - SHOP-FE
        - MS
        - SHOP
        - BT
      - medle:
        - MS-FE
        - BT-FE
        - SHOP-FE
        - MS
        - SHOP
        - BT
    + 东哥：例题（https://mp.weixin.qq.com/s/ir1Hk06HcT8W_qz0MtyONA）（按标签刷例题，例如：数组部分例题）
    + 剑指offer:例题（book + leetcode）
2. base阅读
3. 《剑指offer》: 1章/1pd
4. 

### todo记录
- [set的并交集处理](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Set)
  - 基本都是利用遍历
- 请熟悉和练习Array.sort()
- 关于数组中交换元素的几种方式
- 扩展运算符的使用：妙用
- 栈 与 递归的关系
- try catch 报错 
- int 边界值常量
- [阅读下股票买卖问题](https://labuladong.gitee.io/algo/3/26/99/)
- 注意下强制类型转换：尤其数学运算中
- nodejs 调试：vsCode中调试
- [随机数的生成](https://juejin.cn/post/6971687263562383368)
- 回文
  - [回文串](https://mp.weixin.qq.com/s?__biz=MzAxODQxMDM0Mw==&mid=2247484471&idx=1&sn=7c26d04a1f035770920d31377a1ebd42&chksm=9bd7fa3faca07329189e9e8b51e1a665166946b66b8e8978299ba96d5f2c0d3eafa7db08b681&scene=21#wechat_redirect)
  - [回文序列](https://mp.weixin.qq.com/s?__biz=MzAxODQxMDM0Mw==&mid=2247484666&idx=1&sn=e3305be9513eaa16f7f1568c0892a468&chksm=9bd7faf2aca073e4f08332a706b7c10af877fee3993aac4dae86d05783d3d0df31844287104e&scene=21#wechat_redirect)
- [链表的边界问题](https://blog.csdn.net/qq_42639740/article/details/95723114)
  - 有没有什么最佳实践：dummy算一个
- [未通过的高频hard][k个一组的链表反转-思路懂，但是操作起来边界问题等](https://mp.weixin.qq.com/s?__biz=MzAxODQxMDM0Mw==&mid=2247484597&idx=1&sn=c603f1752e33cb2701e371d84254aee2&scene=21#wechat_redirect)

### 未看完的文章
- [需要后面再看下][二分法高阶-hard](https://mp.weixin.qq.com/s?__biz=MzAxODQxMDM0Mw==&mid=2247487594&idx=1&sn=a8785bd8952c2af3b19890aa7cabdedd&scene=21#wechat_redirect)
- [不难,好理解，但是觉得不典型不好分类-就先不做了][田忌赛马-双指针](https://mp.weixin.qq.com/s?__biz=MzAxODQxMDM0Mw==&mid=2247491139&idx=1&sn=10cb35e0056ac8f8c540fccd0156f333&scene=21#wechat_redirect)
- 数组-随机算法系列（整体都不太好）
  - [O1时间的增删改查数据结构：好实现，不难理解，但是第一道例题剩下2个用例过不去，用例量太大，难以排查](https://mp.weixin.qq.com/s?__biz=MzAxODQxMDM0Mw==&mid=2247487414&idx=1&sn=2be87c0c9279da447f8ac8b8406230fe&scene=21#wechat_redirect)
  - [带权重的随机算法](https://mp.weixin.qq.com/s?__biz=MzAxODQxMDM0Mw==&mid=2247492884&idx=1&sn=e9583238c67e417df41feaa4ed62871d&scene=21#wechat_redirect)
  - [随机算法之水塘抽样算法](https://mp.weixin.qq.com/s?__biz=MzAxODQxMDM0Mw==&mid=2247484974&idx=1&sn=795a33c338d4a5bd8d265bc7f9f63c03&scene=21#wechat_redirect)


## 题型和武器库
### 数组
  - 滑动窗口
    - 题型：  
      - 两个串 具有包含关系的 

### 学到的小笔记
1. 初始化一个数组长度为6,并给每个位置设置元素为0：new Array(6).fill(6)
2. TODO： 记录下：node+vscode调试：左侧菜单栏 - 调试菜单 - 左上角选项：nodejs - run current File - 三角形开始调试

### 工具：
- 0 刷题计时器- [秒表28min=Medium](https://naozhong.net.cn/jishiqi/#countdown=00:28:00&date=2022-01-31T20:33:53&sound=xylophone&loop=1)