# 资料
[高频js面试题-上](https://juejin.cn/post/6940945178899251230)

## 学习指导
0. 题目： 100道左右 每道：1min = 100min 批卷：每道1min = 100min, 找出要补的点 去学习
1. 先通读一遍
  - 先过一遍问题：自问自答一下 - 每个思考1min - 写出答案 然后自己对
  - 再看答案 再对照答案 决出要处理的部分
  - 把不熟悉的 需要系统化的部分 记录下来
2. 再精读一遍 - 系统化搞懂每一个知识点（配合js高程4）
3. 理解问题 就是问题回答了一半
4. 先把这13套题 - 哪怕背会，然后，再从中筛选 - 进行专项学习 和 部分进行系统化学习
  - 最终知识要织进你的知识体系中
    - 知识体系：金字塔 分层 - 每一层有每一层的结构
5. 哪怕背 也要背下来


## 数据类型
1. 类型：
  - me: null undefined number string object Regexp array 新增：symbol map weakMap Set weakSet
  - [?]symbol
  - [?]几个新增的数据结构 不够了解
2. 数据类型检测
  - me：
  ```js
  1. typeof 不能区分 null array object ?
  2. Object.prototype.toString.call()
  3. instanceOf 适用于引用类型
  4. Array.isArray() 判断Array
  5. construct() ?
  ```
3. 判断数组
  - me:
  ```js
  1. Array.isArray()
  2. instanceOf Array ?
  3. Object.prototype.toString.call() === '[Array Object]' ?
  ```
4. null vs undefined
  - me：
  ```js
  1. null 是Object类型        
  undefined 不属于Object类型 不主动赋值的变量会给undefined
  ```
5. typeof null = ? why ？
  - me:
  ```js
  1. 'Object'
  2. null 属于Object类型？
  ```
6. instanceOf 实现原理 和 实现
  - me
  ```js
  原理：js对象集成采用原型链的方式实现 
  实现：
  const myInstanceOf(left, right) {
    let leftProto = Object.getPrototype(left)
    const rightProto = Object.getPrototype(right)
    while(!leftProto) {
      if (leftProto === rightProto) return true;
      leftProto = Object.getPrototype(leftProto)
    }
    return false;
  }
  ```
  - 评：
    - Object APi 不是很熟悉 常用的还是需要熟悉下
7. 0.1 + 0.2 !== 3 why？如何让其相等？
```
js采用了浮点的方式表示小数，所以，小数是不精准的？
```
8. 如何获取安全的undefined值？
  - me:
  ```
  1. ?.?. es6安全取值 专业名称？
  2. lodash.get 
  3. a && a.b && a.b.c || '' 这样的方式取值
  4. 进行防御 if (!a) xxx
  ```
9. typeof NaN
  - me:
  ```
  Number
  ```
10. isNaN 和 Number.isNaN区别？
  - me: ?
11. == 强制转换规则
  - me:
  ```
  1. false: undefined null '' NaN 
  2. true: 非以上的
  ```
12. 其他值到字符串的转换规则
  - me:
  ```js
  - ？？
  - 基础类型：该值本身会加上引号，编程字符串
  - 引用类型：调用自身的toString()函数，例如：object.toString() = 'object'
  ```
13. 其他值到布尔值的转换规则
  - me: 
  ```
  1. false: undefined null '' NaN 
  2. true: 非以上的
  ```
14. && || 的返回值
  - me:
  ```
  在if中 返回布尔值
  在赋值表达式中：在沿着逻辑路径判断 取符合逻辑路径的值
  ```
15. Object.is() 和 == === 的区别？
   - me:
   ```js
   判断2个对象是否相等？
   ```
   - [评注:弱]：object相关api不熟悉
16. 包装类型？
  - me: 
  ```js
  1. 一般的bool 数字 字符串等基础类型都可以使用包装类型 进行包装 包装后，会变成对象，很多基础类型调用方法和属性的时候 实际上都是被runtime/js引擎解析为包装类型 调用的toString 等各种方法 实际上都是通过包装类型提供的方法
  ```
17. js如何进行隐式类型转换？
- me:
```
1. number 2 string; '' + number => string
2. !! + 其他 =》 bool
3. + 其他 => 数字
```
18. + 什么时候用于字符串的拼接？
- me:
```
在表达式中，当+的一端为字符串类型时，+会起到拼接字符串的效果
```
19. bigint提案的背景？
- me: 
```
1. js采用浮点的方式存储小数，并且大数会有精度损失，因此需要一个新的类型来处理述树枝更大 精度要求更高的数据
```
20. iobject.assigin 和 ... 是深拷贝还是浅拷贝？ 两者的区别？
- me:
```
1. 浅拷贝
  - 对于引用类型的值，不会完全拷贝
2. 区别？
```
- 评：object array string number 这几个类型的api都梳理下



## ES6
TODO:
1. 需要重读：《understanding ES6》

1. me：
```
块级作用域：let const
只读：const
```
2. me:
```
const对象的属性可以修改
```
3. new 一个箭头函数会怎样？
me:
```js
？？
```
4. 箭头函数 和 function ?
me:
```js
1. this指向：
  function中的this是window  或者 调用的this 或者 undefined
  箭头函数：this会沿着作用域一直向上寻找 - 直到window
2. function: 可以利用原型new出实例
```
5. 箭头函数this指向？
me:
```js
1. 离最近作用域的this
2. 如果找不到 沿着作用域链想上寻找 直到window
```

6. 扩展运算符的作用和使用场景
me:
···
1. 对象的展开
2. 数组的展开
3. 函数参数的收敛
···
[评]表述太不专业了

7. proxy可以实现的功能
me:
```
1. 可以监听元素的一些操作，例如：get set操作，著名的例子：vue3.0用proxy实现了对对象set get的监听，代替了vue2.0中defineProperty的get set
```
[?延伸：vue用proxy代替defineProperty的get set 有什么好处？有什么不好的？
- 不好的 对浏览器兼容不太友好
- 好处：性能应该更好

8. 对对象和数组解构的理解
me:
```
？解构？
1. 可以直接从对象和数组中取出某一元素
2. 浅拷贝
```
[评]看到这里 我的感觉是你应该看下 《undestanding es6》和《es6 标准解读》了 你懂 但是你说不出来

9. 如何提取高度嵌套的对象里的指定属性
me：
```
高度嵌套对象 意味着可能会有很多不确定 需要做好防御
1. ?.
2. lodash.get ??
function get(obj, key) {
  if () {
    
  }
}
```

10. 对rest参数的理解
```
1. 数组形式呈现
2. 只能使用在箭头函数中
```

11. ES6中的模板语法和字符串处理
```js
1. `${a}` 可以换行

字符串处理？
```



## js基础
TODO: 
- 《js高程4》再看一遍 欠的 总是要还的
1. new操作符的实现原理
me: ??
```js
function new(ClassFn, args) {
  const res = function() {}

  if (classFn instanceOf 'function') {
    return ClassFn(args);
  }
}
```

2. map 和 Object 的区别
me:
```
1. map 和 object 都可以存储k:v形式的数据
2. map的增删改查 都有专门的操作方法；object 也有自己的方法
3. 底层的数据结构不一致 ？
```

3. map 和 weakMap的区别？
me:
```
1. 对于不使用的key weakMap会进行treeShaking
```

4. js内置对象？
me:
```
1. Array function Regexp window? 
```

5. 常用的正则表达式有哪些？
me: [弱] 正则啊 需要140min去练习 去体系化知识 一直很薄弱
```
```

6. 对json的理解
me:
```
1. 一种树形 嵌套性 k:v 型的数据结构
2. 独立于语言之外 可以被序列化和反序列 json.stringify 和 json.parse
```

7. js延迟加载的方式？
```
html <script>
defends： 无序 谁先加载好久执行谁
async: 有序 串行 全被加载完 才会执行：对执行顺序有要求的
```
## 原型
## 异步编程
## 执行上下文/作用域链/闭包
## this/all/apply/bind
## 面向对象
## 垃圾回收与内存泄露