## 阅读
- [VsCode插件开发](https://km.sankuai.com/page/955056876)
- [源码阅读-路径补全pathComplete](https://github.com/ionutvmi/path-autocomplete)
- [源码阅读-代码补全pathIntell](https://github.com/ChristianKohler/PathIntellisense)
```
需要读2遍
```

## 书签
- [12-23](https://km.sankuai.com/page/955056876#id-3.3.1.4%E8%87%AA%E5%8A%A8%E4%BF%AE%E5%A4%8D)

