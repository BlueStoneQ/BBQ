# 主旨
- 作为源码阅读的一阶，头阵


## 原理
### MVVM
### 响应式
#### 双向数据绑定原理
- 核心原理：Object.defindeProperty中的访问器属性中的 get和 set方法
- 角色：data - watcher - render - (new)v-node-tree - diff - dom
#### vue如何监听data变化
- 缺点
深度监听obj，需要递归到底，一次性计算量大，如果数据过大页面，页面可能会卡死
无法监听新增属性/删除属性（所以vue提供了Vue.setVue.delete）
无法原生监听数组，需要做特殊处理
### vdom和diff
#### vdom
- js形式的html代码（一种用来描述dom的json-schema）
#### diff算法，新旧vnode对比，计算出最小的更新范围(本质上是一种优化)
- 算法核心
同层级比较（只比较同一层级，不跨级比较）
tag 不相同，则直接删除重建，不在深度比较
tag 和 key，两个都相同，则认为是相同节点，不在深度比较

### 渲染过程
#### 初次渲染过程
- 解析模板
  - 模板解析为render函数
- 分析依赖
  - 触发响应式：通过set get
    - 模板中没有用的data数据就不会触发getter,因为和视图没关系（vue里面的优化）
- render-vnode - patch(diff并渲染到dom上)
#### 更新过程
- me:更新图很重要
- 修改data 
- render - vnode
- patch（diff - dom）
#### 详细过程：
1、编译模板生成render函数，生成vdom
2、执行render函数，触发data中的getter
3、getter方法收集依赖（通俗点就是,在模板里面触发了哪个变量的getter,就把哪个变量观察起来）
4、在依赖中setter修改data中的数据的时候，Notify看下修改的那个数据是不是之前被观察起来的
5、如果是之前观察起来的，就重新渲染（ re-render），重新生成render函数,生成newVdom形成一个闭环

# 参考
- [十分钟浅入Vue 原理](https://zhuanlan.zhihu.com/p/138114429)  
  - [vdom与diff-vue实现](https://github.com/answershuto/learnVue/blob/master/docs/VirtualDOM%E4%B8%8Ediff(Vue%E5%AE%9E%E7%8E%B0).MarkDown)
  - [解析vue2.0的diff算法](https://www.jianshu.com/p/22f82cc60285)

# TODO
- 自己根据这个原理：手写一个vue-min，实现以上核心能力即可
  - 功能问题驱动：好比现在你要实现一个diff算法 你会怎么做 实现过程遇到问题 就可以参考vue的实现
