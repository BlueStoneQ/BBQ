## target
1. 理解webpack原理 可以叙述 并 画出来
2. 手写一个min-webpack，轻快 不用写单测之类的，但是得能用，可以测过自己的小项目
3. 学这些的目的：理解现代前端的工程化本质 - 才会举一反三，看到本质 才能一劳永逸



### 分析依赖结果
```js
// 依赖map是一个json对象
{
  'path/js': {
    dependences: {
      './a.js': 'src/a.js',
    },
    code: "\"use-strict\";\n\nvar_a = require("./a.js")"
  }
}
```

- 我们是使用 for 循环实现了分析所有依赖，之所以循环可以分析所有依赖，注意 modules 的长度是变化的，当有依赖的时候 .modules.push 新的依赖，modules.length 就会变化。
  - 也就是我们的依赖map其实是一个一维的，不是嵌套的树状的，然后打包后的代码中，import被替换为了require,注入的自己实现的require会根据路径进行依赖在module_map中查找

### 运行时加载依赖require
- 编译后我们源代码的 import 会被解析成 require 浏览器既然不认识 require ，那我们就先声明它
  - 可以看到：在自定义的require中 会进行eval(code)

## 摘录

## 问题引导思考
- 如果出现组件循环引用那又应该如何处理？
- Webpack 是如何加载 loader 的？
- 犹大大极力推荐的 vite 可以实现按需打包，大大降低开发时候打包速度，如果是 webapck 又是应该如何实现？
- webpack的插件机制？

## 参考
- [Webpack 原理——如何实现代码打包](https://www.zoo.team/article/webpack-reason)
- [webpack官网中字](https://webpack.docschina.org/concepts/)
- [webpack-工程化打包原理解析与实现](https://github.com/airuikun/front-core/issues/4)
- [webPack原理浅析](https://jelly.jd.com/article/5f0de6dad5205e015b87c128)
- [万字总结-webpack原理解析](https://zhuanlan.zhihu.com/p/363928061)