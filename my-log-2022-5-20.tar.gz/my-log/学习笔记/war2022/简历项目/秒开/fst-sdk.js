// 简易手写一个秒开测速sdk 可以放到工程里测一测
const config = {}; // global
const fst = {
  records: [], // 采样点记录

};

const register = function() {}

const pageBase = function() {}


function pageHook() {}

function componentHook() {}

function report() {}

function sampling() {
  // sampling
  // isReachedBottom
  // tryComputedFst
}

