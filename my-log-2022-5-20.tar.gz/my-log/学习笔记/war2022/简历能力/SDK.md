
## 秒开SDK
- 那张图
## 探针SDK


### 参考
- [SDK设计](https://segmentfault.com/a/1190000040796868#item-1-11)


