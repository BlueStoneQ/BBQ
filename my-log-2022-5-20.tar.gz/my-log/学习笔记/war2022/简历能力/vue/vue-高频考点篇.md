## 基础
### 基本原理
- 依赖收集时机：一个Vue实例创建时 - 变成响应式对象 - 在getter被触发的时候 就会触发收集依赖的逻辑
### 双向绑定原理
- Vue本质是单向数据流
- 双向数据流：只是v-model语法糖
### defineProperty的缺陷
- 以下情况无法触发：
  - 数组下标修改数据，数组的长度改变
  - 对象新增和删除属性
### 如何拦截数组的操作？？
- 为什么vue不使用Object.defineProperty来完成对数组的监听呢？通过网上查阅，发现使用Object.defineProperty监听数组性能很差，方便性得到的好处小于性能带来的损失，得不偿失。
- 中间层我们给他起个名字arrayMethods, 我们让数组实例array的__proto__属性指向arrayMethods, arrayMethods的__proto__属性指向Array.prototype，这样，当我们通过实例去访问数组的变异方法时，根据原型链的查找规则，会先在arrayMethods对象中查找， 这样，我们就实现了对数组变异方法的拦截， 代码如下
```js
// 数组的变异方法
const variationMethods = ['splice', 'sort', 'push', 'pop', 'reverse', 'shift', 'unshift']
// 缓存数组的原型对象
const tmpArrayPrototype = Array.prototype
// middLayer继承数组的原型对象，即middleLayer.__proto__ = Array.prototype
const middleLayer = Object.create(Array.prototype)
variationMethods.forEach(method => {
  // 变异方法全部在middleLayer对象上实现一遍
  middleLayer[method] = function(...args) {
    // 实际执行的还是Array.prototype对象上的方法
		const result = tmpArrayPrototype[method].apply(this, args)
    console.log(`拦截到了${method}方法的执行`)
    // 在这里做一些vue响应式的额操作 例如 Dep.update()
    return result
  } 
})

// 更改下数组实例的原型链指针 指向，这样优先查找到的就是 middLayer上重写的方法
const arr = []
arr.__proto__ = middleLayer
// 由于_proto__不是每个浏览器都支持 所以 下面直接将方法挂载到实例上
const arr = []
const arrayKeys = Object.getOwnPropertyNames(middleLayer)
arrayKeys.forEach(method => {
  Object.defineProperty(arr, method, {
    enumerable: false, // 不允许枚举出来 也就是不污染数组实例的枚举属性
    writable: true,
    configurable: true,
    value: middleLayer[method]
  })
})
```
### keep-alive
- 当组件在keep-alive内被切换时组件的activated、deactivated这两个生命周期钩子函数会被执行 被包裹在keep-alive中的组件的状态将会被保留
### v-if&&v-show
- v-if是动态的向DOM树内添加或者删除DOM元素；v-show是通过设置DOM元素的display样式属性控制显隐；
- v-if有更高的切换消耗；v-show有更高的初始渲染消耗；
### v-model
- value + input的语法糖
```html
<input
  v-bind:value="searchText"
  v-on:input="searchText = $event.target.value"
>
```
### $nexttick
- nextTick 不仅是 Vue 内部的异步队列的调用方法，同时也允许开发者在实际项目中使用这个方法来满足实际应用中对 DOM 更新数据时机的后续逻辑处理
### vue模板编译原理
- template -> js函数 -> 浏览器执行该函数，渲染出html
### vue-loader
- template -> js render

## 生命周期
### 生命周期hook
- create: 创建vue实例
  - beforeCreade:
  - created: 实例创建完成，data等可以访问,可以ajax了哦
    - 如果要访问DOM, 可以将访问DOM的代码放在vue.$nexttick中
    - 建议将ajax请求放在这个时机中哦
- mount: 将实例渲染成html + 挂载到页面上
  - beforeMounted: 实例 -> html，但还未挂载到页面上
  - mounted: 挂载到页面中，可以访问vm.$el
- update:
  - beforeUpdate: 响应式数据已经改变，但是DOM还未改变
  - updated：DOM已经更新，避免在此更新data,容易导致无限循环
    - 服务端渲染期间不会调用
- destroy:
  - beforeDestroy：实例仍可用，this可获取到实例
  - destroyed

keep-alive：
  - deactivated:当组件被换掉时，会被缓存到内存中、触发
  - activated: 当组件被切回来时，再去缓存里找这个组件、触发
  
### 父子组件生命周期函数执行顺序
- 加载
  - 父：created -> beforeMounted
  - 子：...beforeMounted -> mounted
  - 父：mounted
- 更新
  - 父：beforeUpdate
  - 子：beforeUpdate -> updated
  - 父：updated
- 销毁
  - 父：beforeDestroy
  - 子：beforeDestroy - updated
  - 父：destroyed
## 组件通信
```
因为父组件->子组件： props是现成的主流方案
其实组件通信主要是考察：
父组件获取子组件信息
兄弟组件的互相通信
```
- props+$emit （父子）
- eventBus: $emit / $on （兄弟组件通信）
  - eventBus可以自己开发 也可以使用用new Vue()
  ```js
  // compA
  eventBus.$emit('eventName', { a: 1 })
  // compB
  eventBus.$on('eventName', (param) => {
    this.b = param.a;
  })
  ```
- provide / injext （隔代通信）
  - 注意：有一个通信方案：状态提升，提升到父组件 然后向下派发：
  - 本质上是2个hook:
  ```js
  // 祖先节点 
  // provide很像data
  provide() { 
    return {     
        num: this.num,
        app: this // 传递所有属性
    };
  }
  // 子孙节点
  inject: ['num', 'app']
  console.log(this.num);
  console.log(this.app.num);
  ```
- ref/$refs
  - 获取当前子组件数据
  ```vue
  <template>
    <comp1 ref="child"></comp1>
  </template>
  <script>
    export default {
      console.log(this.$refs.child.data1);
      console.log(this.$refs.child.method1());
    }
  </script>
  ```
- $parent/$root $children （对各个层级的实例引用）
  - this.$children[0].message = 'JavaScript'
- 借助vuex 统一管理状态
## 路由
### 懒加载？
- 需要webpack配合？
  - 是的 webpack会根据分割点进行分割打包，分割点：
    - webpack.splitchunk的配置
    - vue-router懒加载 - 动态加载的依赖会单独打包
    - vue组件懒加载-动态加载-单独打包
- 懒加载：
  - 路由懒加载
  - 组件懒加载
  ```js
  const comp = () =>  import('./comp')

  // vue config
  {
    'comp': comp
  }
  ```
- 路由懒加载三种方式：
```js
new Router({
 routes: [{
   path: '/a',
   name: 'hello',
   // （主流）形式1 ES import，- 需要配置巴格莱：打开babel.config.js文件，将@babel/plugin-syntax-dynamic-import配置到plugins数组当中
   component: () => import(/* webpackChunkName: "chunk-1" */'@components/Hello');
   // 形式2 require动态加载
   component: resolve => require(['@components/Hello'], resolve)
   // 形式3 webpack require.ensure - require.ensure这个方式就不记了
   component: r => require.ensure([],() =>  r(require('@/components/HelloWorld')), 'home')
 }] 
})

```
### hash & history
- hash
```js
hash & window.onhashchange(event) {
  event.oldURL
  event.newURL
}
```
- history:
  - 需要后端配置支持 否则 会404
    - hash & window.onhashchange(event) {}
  - api:
    - 修改历史状态：pushState() replaceState()
    - 切换历史状态: forward() back() go()console.log('', )
### 路由参数传递？动态路由
参数传递：
- 动态路由
```js
// js 跳转
this.$router.push({
  path: `/describe/${id}`,
})
// 路由配置
{
  path: '/describe/:id'
}
// 获取参数
this.$route.params.id
```
- params:
  - url中不显示，传值
  - 刷新会丢失携带的数据
  ```js
  // 上一页
  this.$route.push({
    name: 'Describe',
    params: {
      id: id
    }
  })
  // 路由配置 可以加：id 也可以不加，加的话 会在url中显示
  // 下一页
  this.$route.params.id
  ```
- query
  - url中携带，相当于拼接在url中
  - 刷新不会丢失携带的数据
  ```js
  // 传递
  this.$router.push({
    path: '/xxx',
    query: {
      id: id
    }
  })
  // 获取
  this.$route.query.id
  ```
- 直接手动拼接到url中
获取参数：
- this.$router.query
### js跳转
- <router-link>底层也是调用这2个api
- this.$router.push()
  - <router-link to="xxx">
- this.$router.replace()
  - <router-link to="xxx" replace>
  - this.push()
- this.$router.go()
### 导航守卫
- 其实就是拦截器
- 全局钩子：（一般全局before优先， after垫后）
  - router.beforeEach
  - router.beforeResolve - beforeRouteEnter之后调用
  - router.afterEach
- 单个路由钩子：
  - beforeEnter: 配置在route中
- 组件内钩子：
  - beforeRouteEnter:进入组件之前会被调用
  - beforeRouteUpdate：例如：在 /foo/1 和 /foo/2 之间跳转的时候，由于会渲染同样的foa组件，这个钩子在这种情况下就会被调用
  - beforeRouteLeave：离开组件被调用
### 动态路由
- router.addRoute()
- router.removeRoute()
### 嵌套路由
- route配置中增加children配置
- 组件中可以用<vvue-router>对渲染位置进行占位
### vue-router前端路由原理
```
前端路由其实就是感知路由现在走到了哪儿
然后映射到相关的组件渲染
渲染就交给vue了 自己确认渲染的组件和地方
（<router-view>更像个占位符）
```
- [参考](https://www.hepengfei.net/vue/122.html)
- 核心：
  - VueRouter核心是，通过Vue.use注册插件，在插件的install方法中获取用户配置的router对象。当浏览器地址发生变化的时候，根据router对象匹配相应路由，获取组件，并将组件渲染到视图上。
- url变化，但是不能刷新，不能向服务器请求
- 浏览器默认展示history最上面的url
- 2大场景：
  - 代码中跳转：
    - hash: 
      - push = window.location.hash = xxx
      - replace = window.location.replace(xxx)
    - hostory:
      - push = history.pushstate
      - replace = history.replaceState
  - 地址栏输入url后刷新：
    - hash:
      - 监听：window.hashchange,在该事件回调中，直接调用this.replace()
    - hostory:
      - 监听：popstate事件，在该事件中，直接调用this.replace()
- 渲染流程：
```js
this.$router.push(path)
 -->  
HashHistory.push() 
--> 
History.transitionTo() 
--> 
const  route = this.router.match(location, this.current)会进行地址匹配，得到一个对应当前地址的route(路由信息对象)
-->
History.updateRoute(route) 
 -->
 app._route=route (Vue实例的_route改变)   由于_route属性是采用vue的数据劫持，当_route的值改变时，会执行响应的render( )
-- >
vm.render()   具体是在<router-view></router-view> 中render
 -->
window.location.hash = route.fullpath (浏览器地址栏显示新的路由的path)
```

### hash 和 history模式的比较
- pushState设置的新URL可以是与当前URL同源的任意URL；而hash只可修改#后面的部分，故只可设置与当前同文档的URL。
  - 其实就是设置hash的动作是这样的：window.location.hash = xxx,比较有局限性
  - 后面的路由都是：url#a/b/c 这样的
- pushState设置的新URL可以与当前URL一模一样，这样也会把记录添加到栈中；而hash设置的新值必须与原来不一样才会触发记录添加到栈中。
- pushState通过stateObject可以添加任意类型的数据到记录中；而hash只可添加短字符串。
- pushState可额外设置title属性供后续使用。
### hitory模式的配置
- 需要在后端进行额外配置
- 原因：如果没有适当的服务器配置，用户在浏览器中直接访问 https://example.com/user/id，就会得到一个 404 错误（其实就是在地址栏直接输入url会导致404）
- 解决方案：要解决这个问题，你需要做的就是在你的服务器上添加一个简单的回退路由。如果 URL 不匹配任何静态资源，它应提供与你的应用程序中的 index.html 相同的页面（后端将url定位到index.html，返回整个SPA的index.html,然后你在popstate#callback中进行前端路由加载）
### vue-router需要系统掌握

## Vuex
### 使用
```js
// 定义store 可以分模块
const store = new Vuex.Store({
  state: {
    count: 0
  },
  mutations: {
    increment (state) {
      state.count++
    }
  },
  actions: {
    increment (context) {
      context.commit('increment')
    }
  }
})


// 注册
new Vue({
  el: '#app',
  store
})

// 组件中使用
this.$store.commit('increment') // 直接触发mutation
// 通过action触发
this.$store.dispatch('increment');
```
### vuex的模块化
```js
const moduleA = {
  state: () => ({ ... }),
  mutations: { ... },
  actions: { ... },
  getters: { ... }
}

const moduleB = {
  state: () => ({ ... }),
  mutations: { ... },
  actions: { ... }
}

const store = new Vuex.Store({
  modules: {
    a: moduleA,
    b: moduleB
  }
})

store.state.a // -> moduleA 的状态
store.state.b // -> moduleB 的状态
```
### matation为甚不能做异步操作
- Vuex中所有的状态更新的唯一途径都是mutation
- 每个mutation执行完成后都会对应到一个新的状态变更，这样devtools就可以打个快照存下来，然后就可以实现 time-travel 了。如果mutation支持异步操作，就没有办法知道状态是何时更新的，无法很好的进行状态的追踪，给调试带来困难。
### vuex严格模式
- 状态更改必须由matation引起，否则将抛出错误
```js
new Vuex.Store({
  strict: true
})
```
### getter + mapGetters
```js
import {mapGetters} from 'vuex'
export default{
    computed:{
        ...mapGetters(['total','discountTotal'])
    }
}
```
### 将mutation映射到method上
```js
import { mapMutations } from 'vuex'

export default {
  // ...
  methods: {
    ...mapMutations({
      add: 'increment' // 将 `this.add()` 映射为 `this.$store.commit('increment')`
    })
  }
}
```
## Vue3.0
### Vs 2.0
- 监测机制：proxy -> defineProperty
- 使用TS实现 对TS支持较好
### defineProperty和proxy的区别
- defineProperty的缺陷：
  - 增加 删除对象属性 监测不到
  - 数组下标 和 长度变化 监测不到
  - 会改变原始数据
- proxy优点：
  - 全方位监测 对象 数组的变化
  - 不会改变原始数据 会提供一个代理对象
  - 支持Map Set WeakMap WeakSet
## 虚拟DOM
### vNode的优点
- 减少频繁的DOM操作，符合MVVM模型
- 利于跨平台，跟平台耦合度较低
- 相比于DOM直接操作，保证了性能下限
### patch过程
- tempalte -> renderFn -> DOM
- 更新：
  - new VNode Tree -> old VNode Tree ,比对后记录下两棵树的差异
  - 将记录的2棵树的差异应用到真正的DOM中去
### key的作用
1. 用来标记唯一元素，当diff中key一致时，会人为是同一元素，采用复用的策略，跟踪元素身份，实现高效复用
2. index作key的话，不能保证key唯一标记对应的元素，排序后，key和元素会对不上
## vue的webpack配置+工程徒手搭建
- vue-cli