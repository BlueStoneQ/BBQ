### vue复用方案
- [官网-复用专题](https://cn.vuejs.org/v2/guide/mixins.html)
- 复用的方案：
  - mixin
  - 自定义指令
  - 渲染函数 & jsx
  - 插件
  - 过滤器
  - extends