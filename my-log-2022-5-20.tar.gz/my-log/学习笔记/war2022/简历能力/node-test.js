// 注册任务
// 并行控制分为：按任意顺序注册任务 - start任务
const tasks = [];
let completedTasks = 0; // 计数器 - 已经完completedTasks === tasks.length务数量

const task1 = function(result) {
  return Promise.resolve().then(() => {
    console.log('1', result);
    checkIfCompleted();
  });
}

const task2 = function(result) {
  return Promise.resolve().then(() => {
    console.log('2', result);
    checkIfCompleted();
  });
}

// 按顺序注册任务
tasks.push(task1);
tasks.push(task2);
// 确定任务数量
// 校验：得到结果数量是否 === 任务数量 则全部任务完成
function checkIfCompleted() {
  completedTasks++;
  if (completedTasks === tasks.length) {
    console.log('并行任务完成');
  }
}

// 遍历任务队列 触发任务
for (const task of tasks) {
  task();
}