## 参考
- [webpack教程](https://juejin.cn/post/7023242274876162084#heading-14)
- [webpack考点](https://juejin.cn/post/7023242274876162084)
- [webpack打包原理](https://segmentfault.com/a/1190000021494964)

# 核心概念
## module，chunk 和 bundle 的区别是什么？
- [webpack易混淆概念](https://juejin.cn/post/6844904007362674701#heading-0)
- module，chunk 和 bundle 其实就是同一份逻辑代码在不同转换场景下的取了三个名字：
我们直接写出来的是 module，webpack 处理时是 chunk，最后生成浏览器可以直接运行的 bundle。

# loader
## CDN与publicpath
- 在构建过程中，将引⽤的静态资源路径修改为CDN上对应的路径。可以利⽤webpack对于 output 参数和各loader的 publicPath 参数来修改资源路径

