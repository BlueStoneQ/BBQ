#!/bin/sh

ls -l