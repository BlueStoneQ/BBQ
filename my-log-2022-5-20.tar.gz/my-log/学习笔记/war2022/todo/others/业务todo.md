```
后续每周的工作
就从这里找
```
## bugfix
- 展位时间有问题：应该给1-5天生效时间：估时1pd 排期：2pd
  - [活动生成器](https://km.sankuai.com/page/1222704342)
- 使用babel: 给物料引入构建 - forMyFace
  - 刚好可以编写一个babel插件
  - babel专项
  - 工程化：构建专项