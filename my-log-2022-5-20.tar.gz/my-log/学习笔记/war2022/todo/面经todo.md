## 米哈游
```
米哈游明显问的很具体
希望巩固自己的能力 真金不怕火炼
重视如何落地
```
1.如何手动搭建一个vue项目（不使用脚手架，如何进行展开）
2.webpack中的alias,如何进行配置
3.proxy，object.defineProperty()的原理，比如A对象里面有个B属性，如何使用 object.defineProperty()，进行对B属性改变的监听。proxy同理，如何实现
4.webpack的Eslint是什么作用以及如何配置
5.const定义对象，定义数组，改变对象或数组的某个元素，是否报错
6.MVVM和MVC区别