# vue基础
# 生命周期
# 组件通信
# 路由
# 虚拟DOM
# Vuex
# Vue 3.0
