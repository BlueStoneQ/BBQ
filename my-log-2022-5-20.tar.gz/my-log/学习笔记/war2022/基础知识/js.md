# 数据类型
# 基础
# ES6
# 原型
## 原型链
- 指向原型：
  - constructor.prototype 
  - new ClassA().__proto__
# 异步编程
# 执行上下文、作用域链、闭包
# this call apply bind
# 面向对象
# 垃圾回收 与 内存泄露