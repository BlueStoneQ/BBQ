# 课程
- [算法就像搭乐高：LFU](https://mp.weixin.qq.com/s?__biz=MzAxODQxMDM0Mw==&mid=2247486545&idx=1&sn=315ebfafa82c0dd3bcd9197eb270a7b6&scene=21#wechat_redirect)
  - Least Frequently Used 最少访问算法
  - LFU 算法要复杂很多，labuladong 进字节跳动的时候就被面试官问到了 LFU 算法。
  - 淘汰访问频次最低的数据，如果访问频次最低的数据有多条，需要淘汰最旧的数据
    - me: 也就是一条数据有2个属性：
      - 访问频次
      - 新旧的时间戳（最近访问时间）
  - 把数据按照访问频次进行排序，而且频次还会不断变化，这可不容易实现。
  - 不要企图上来就实现算法的所有细节，而应该自顶向下，逐步求精，先写清楚主函数的逻辑框架，然后再一步步实现细节。
  - 画图，画图，画图，重要的话说三遍，把逻辑比较复杂的部分用流程图画出来，然后根据图来写代码，可以极大减少出错的概率。
  - 容量已满的时候 - 需要进行淘汰算法


## 数据结构设计
  - 查找：3张hash表(记录3组映射关系-其实是一个三角映射关系)：
    - k:v key: val
      - HashMap存储key到val的映射，就可以快速计算get(key)。
    - k:f  key: freq （LFR的核心)
      - 使用一个HashMap存储key到freq的映射，就可以快速操作key对应的freq
      - 可能有多个key拥有相同的freq，所以 freq对key是一对多的关系，即一个freq对应一个key的列表
      - 希望freq对应的key的列表是存在时序的，便于快速查找并删除最旧的key
      - （freq变化）希望能够快速删除key列表中的任何一个key，因为如果频次为freq的某个key被访问，那么它的频次就会变成freq+1，就应该从freq对应的key列表中删除，加到freq+1对应的key的列表中
    - f:k


## 代码框架
- increaseFreq和removeMinFreqKey方法是 LFU 算法的核心
  - 借助KV表，KF表，FK表这三个映射巧妙完成这两个函数