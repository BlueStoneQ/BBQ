# 原理
# 使用
## API调用分类
### 异步-promise
### 异步-回调
### 同步
## API功能分类
### 读
- stream
### 写
- stream
### 其他
- link
- 权限
- watch
# 背景知识
## 文件类型
- file
- dir
- dev
- link

# 参考
- [dong-文件](https://mp.weixin.qq.com/s/USb5e2Zoc0LRgRShRpTYfg)
- fs-extra github
- chokidar github